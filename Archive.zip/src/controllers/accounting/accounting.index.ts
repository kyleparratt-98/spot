import routes from "./accounting.route";
export default routes;
