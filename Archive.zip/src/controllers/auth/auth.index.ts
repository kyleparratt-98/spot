import routes from "./auth.route";
export default routes;
